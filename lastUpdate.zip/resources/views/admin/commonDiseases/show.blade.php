@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.show') }} {{ trans('cruds.commonDisease.title') }}
    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="{{ route('admin.common-diseases.index') }}">
                    {{ trans('global.back_to_list') }}
                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            {{ trans('cruds.commonDisease.fields.id') }}
                        </th>
                        <td>
                            {{ $commonDisease->id }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.commonDisease.fields.name') }}
                        </th>
                        <td>
                            {{ $commonDisease->name }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.commonDisease.fields.description') }}
                        </th>
                        <td>
                            {!! $commonDisease->description !!}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.commonDisease.fields.image') }}
                        </th>
                        <td>
                            @if($commonDisease->image)
                                <a href="{{ $commonDisease->image->getUrl() }}" target="_blank" style="display: inline-block">
                                    <img src="{{ $commonDisease->image->getUrl('thumb') }}">
                                </a>
                            @endif
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="{{ route('admin.common-diseases.index') }}">
                    {{ trans('global.back_to_list') }}
                </a>
            </div>
        </div>
    </div>
</div>



@endsection