<?php

return [
    'site_title' => 'FarmingForYou',
];
