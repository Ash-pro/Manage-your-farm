<?php

return [
    'site_title' => 'المزرعة الذكية',
];
